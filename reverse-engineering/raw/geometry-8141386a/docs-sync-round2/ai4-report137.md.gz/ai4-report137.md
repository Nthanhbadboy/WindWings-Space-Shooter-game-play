# 137 — `PVP_Manager.GetRankName`: chuỗi hiển thị hạng, từ slot tới chữ (+ đóng `not_decoded` của 136)

**Trạng thái:** `DECODED_STATIC` (chỉ đọc APK gốc, không chạy game)
**Lớp bằng chứng:** STATIC-ONLY; hành vi khi **thiếu key** ngôn ngữ là `MODEL_NOT_MEASURED runtime`.
**Artifact:** `datas/l2_535b0541_rank_name.json.gz` (4118 B, sha256 `1596564d798a9f4ad93bfd582abd92d2dfa559b06362f28dd56cc1d0ae4636b1`)
**Báo cáo trước:** 136 (`not_decoded` #1 = "rank display strings"), 135 (`MaxRankStars`), 12 (bảng localization), 128 (`LanguageAssets`).
**Verifier:** `tools/verify/rank_name.py` · **Test:** `tests/test_rank_name.py` (26 test).

---

## 0. TL;DR

| Câu hỏi | Trả lời đo được | Bằng chứng |
|---|---|---|
| `GetRankName` ghép chuỗi thế nào? | `GetText("txt_pvp_rank_" + rank) + " " + GetRankNumber(rank, level)` | 5 lời gọi có tên trong `dump.cs`, thứ tự đo bằng replay tượng trưng (§1) |
| Hai slot chuỗi 136 để mở là gì? | `txt_pvp_rank_` và `" "` | kind **5** (string literal) → `stringliteral.json` theo địa chỉ literal (§2) |
| Hạng 0..9 tên gì? | `Herald, Guardian, Crusader, Archon, Legend, Ancient, Divine, Immortal, Eternal, God` | 19 bảng `LanguageAssets`, **giống hệt** ở mọi ngôn ngữ (§3) |
| Nhãn "Hạng" lấy từ đâu? | key riêng `txt_pvp_rank` (15 giá trị khác nhau / 19 ngôn ngữ, vd `Hạng`) | §3.2 — **không** phải chuỗi trong `GetRankName` |
| Hiển thị thực tế? | `Herald 3`, `Herald 2`, …, `God 5` … `God 1` (44 dòng) | §4 |
| Đóng được mục nào của 136? | `not_decoded` #1 "rank display strings" → **resolved** | §5 |
| Còn mở? | `LanguageManager.GetText` (RVA 21202600) không nằm trong raw đã pin ⇒ fallback khi thiếu key = runtime | §6 |

**Một câu:** hai chuỗi màu nhiệm của 136 **không** cần thêm dữ liệu nào — raw đã ghi `addend` của slot, và `addend` chính là **địa chỉ literal** trong `stringliteral.json`; phần còn lại là 19 bảng ngôn ngữ đã pin, và cả 19 bảng đều gọi 10 hạng bằng **cùng một bộ tên** (Herald → God).

---

## 1. Chuỗi lời gọi — đo bằng replay tượng trưng

`GetRankName(int rank, int level)` — RVA **19881572**, 264 B.

Verifier **không** đọc assembly bằng mắt: nó chạy lại thân method với **thanh ghi giữ biểu thức** (`x0 = "rank"`, `x8 = LIT("txt_pvp_rank_")`, …), nên thứ tự và đối số của từng lời gọi là kết quả thi hành:

```text
Concat(GetText(Concat(LIT("txt_pvp_rank_"), ToString(rank))), LIT(" "),
       GetRankNumber(rank, level))
```

| # | RVA lệnh | Đích | Chữ ký trong `dump.cs` | Kết quả tượng trưng |
|---:|---:|---:|---|---|
| 1 | 19881692 | 34616120 | `public override string ToString() { }` | `ToString(rank)` |
| 2 | 19881712 | 33439876 | `public static string Concat(string str0, string str1) { }` | `Concat(LIT("txt_pvp_rank_"), ToString(rank))` |
| 3 | 19881756 | 21202600 | `public static string GetText(string key) { }` (class `LanguageManager`, TypeDefIndex 1533) | `GetText(<kết quả 2>)` |
| 4 | 19881796 | 19884996 | `public static string GetRankNumber(int rank, int level) { }` | `GetRankNumber(rank, level)` |
| 5 | 19881816 | 33476420 | `public static string Concat(string str0, string str1, string str2) { }` | `Concat(<kết quả 3>, LIT(" "), <kết quả 4>)` |

Dòng 3 là **mấu chốt**: key `"txt_pvp_rank_" + rank` được đưa vào `LanguageManager.GetText`, tức tên hạng là **dữ liệu bảng ngôn ngữ**, không phải chuỗi nằm trong code.

---

## 2. Hai literal — từ slot tới chữ

Metadata usage slot mã hoá `(kind << 29) | source`; **kind 5** = string literal, và raw ghi `addend` = **địa chỉ literal trong file**. `stringliteral.json` lại được đánh index đúng theo địa chỉ đó, nên phép nối là 1-1, không phải đoán.

| Lệnh | `slot_va` | `addend` = địa chỉ literal | kind | source | **Chữ** |
|---:|---:|---:|---:|---:|---|
| 19881696 | 44960936 | 46080000 | 5 | 28027 | `txt_pvp_rank_` |
| 19881800 | 44940088 | 45968752 | 5 | 209 | `" "` *(một dấu cách)* |

Đúng **2** slot kind-5 trong toàn thân method; mọi slot còn lại là kind 1 (metadata khác), nên không có literal thứ ba bị bỏ sót.

---

## 3. Mười hạng và 19 ngôn ngữ

### 3.1 Tên hạng — giống hệt ở mọi ngôn ngữ

| rank | key | tier |
|---:|---|---|
| 0 | `txt_pvp_rank_0` | Herald |
| 1 | `txt_pvp_rank_1` | Guardian |
| 2 | `txt_pvp_rank_2` | Crusader |
| 3 | `txt_pvp_rank_3` | Archon |
| 4 | `txt_pvp_rank_4` | Legend |
| 5 | `txt_pvp_rank_5` | Ancient |
| 6 | `txt_pvp_rank_6` | Divine |
| 7 | `txt_pvp_rank_7` | Immortal |
| 8 | `txt_pvp_rank_8` | Eternal |
| 9 | `txt_pvp_rank_9` | God |

Kiểm: **19/19** file `LanguageAssets` có đủ **10/10** key, và với mỗi key, tập giá trị trên 19 ngôn ngữ có **đúng 1 phần tử** (190 phép so, 0 lệch). Nghĩa là tên hạng **không được dịch** — chỉ nhãn mới dịch.

### 3.2 Nhãn (`txt_pvp_rank`, không có `_số`)

`txt_pvp_rank` là key **khác** (dùng cho label UI, không đi qua `GetRankName`): 19 ngôn ngữ → **15 giá trị khác nhau** (`Hạng`, `Rang`, `Rango`, `Classificação`, `Pangkat`, `Hodnost`, …). Cùng họ còn `txt_pvp_rank_rewards` (19/19 ngôn ngữ), cũng không đi qua method này.

Nên chuỗi hiển thị **không** phải "Hạng 3" mà là "Herald 3": nhãn "Hạng" do UI tự ghép ở chỗ khác.

---

## 4. Bảng hiển thị (44 dòng = tổng số ô của 135)

`GetRankNumber` trả `số ô − level` (136 §4), nên **số hạng đếm ngược**: level 0 là số lớn nhất.

| rank | level 0 | level 1 | level 2 | level 3 | level 4 |
|---:|---|---|---|---|---|
| 0 Herald | `Herald 3` | `Herald 2` | `Herald 1` | — | — |
| 1 Guardian | `Guardian 3` | `Guardian 2` | `Guardian 1` | — | — |
| 2 Crusader | `Crusader 4` | `Crusader 3` | `Crusader 2` | `Crusader 1` | — |
| 3 Archon | `Archon 4` | `Archon 3` | `Archon 2` | `Archon 1` | — |
| 4 Legend | `Legend 5` | `Legend 4` | `Legend 3` | `Legend 2` | `Legend 1` |
| 5 Ancient | `Ancient 5` | … | | | `Ancient 1` |
| 6 Divine | `Divine 5` | … | | | `Divine 1` |
| 7 Immortal | `Immortal 5` | … | | | `Immortal 1` |
| 8 Eternal | `Eternal 5` | … | | | `Eternal 1` |
| 9 God | `God 5` | `God 4` | `God 3` | `God 2` | `God 1` |

Đây là **chuỗi hiển thị**, không phải "điểm": điểm PvP là `int` của 136 (`rank·1e6 + level·1e5 + star·1e4 + point`).

---

## 5. Đóng `not_decoded` của 136

| 136 nói | 137 |
|---|---|
| "chuỗi tiền tố nằm ở static slot `0x2ADCAE0` / `0x2ADB0B38` mà raw không resolve" | **sai ở phần "không resolve"**: slot kind-5 + `addend` = địa chỉ literal ⇒ tra được `txt_pvp_rank_` và `" "` |
| "không trích dẫn được tên hạng" | tên hạng lấy từ `LanguageAssets`, đủ 10/10 key ở 19/19 ngôn ngữ |

**Không sửa artifact 136** (đã handoff): đính chính nằm ở đây + `confirmations` của 137.

---

## 6. `not_decoded` (1 mục)

| Mục | Bước chặn |
|---|---|
| Hành vi khi **thiếu key** | `LanguageManager.GetText` (RVA **21202600**) không có trong raw đã pin; không biết khi key vắng thì trả key, chuỗi rỗng, hay fallback ⇒ `MODEL_NOT_MEASURED runtime`. Với dữ liệu đã pin thì **không** xảy ra: 10/10 key có mặt ở 19/19 ngôn ngữ |

---

## 7. Tái lập

```bash
python3 tools/verify/rank_name.py            # in bytes/sha256 + số tier/ngôn ngữ/dòng
python3 -m unittest tests.test_rank_name      # 26 test
python3 tools/verify-claims.py --require AB,AO,AP
```

`evidence: STATIC_ONLY_ORIGINAL_APK` · nguồn: `meta-rewards-535b0541/native.json.gz`,
`reverse-engineering/il2cpp/stringliteral.json`, `reverse-engineering/il2cpp/dump.cs.gz`,
`datas/l2_535b0541_max_rank_stars.json.gz` + 19 file `LanguageAssets` (sha256 từng file trong artifact).

---

`provenance:` APK gốc `535b0541` → `libil2cpp.so` → raw `meta-rewards-535b0541` (body + slot) → `stringliteral.json` (chữ) → `LanguageAssets` (tên hạng) → verifier → artifact 4118 B `1596564d…` → 26 test. Không emulator/probe/device.
