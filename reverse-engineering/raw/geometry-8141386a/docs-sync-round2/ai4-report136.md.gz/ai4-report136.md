# 136 — `PVP_Manager` rank API: codec `ToPoints` / `DataFromPoints` + `GetRankNumber` (đính chính 134, 135)

**Trạng thái:** `DECODED_STATIC` (chỉ đọc APK gốc, không chạy game)
**Lớp bằng chứng:** STATIC-ONLY; cấu hình rank do server trả về là `MODEL_NOT_MEASURED runtime`.
**Artifact:** `datas/l2_535b0541_pvp_rank_api.json.gz` (3172 B, sha256 `7663d2fd12aa78e487f447f5e12afd60809e937bc69d9654604dc2abc141950f`)
**Báo cáo trước:** 127 (§6.5 điểm PvP), 128 (§3.4), 134 (`PVP_Manager` rules + statics layout), 135 (`MaxRankStars` giá trị — báo cáo này tìm ra **method đọc** mà 135 nói là thiếu).
**Verifier:** `tools/verify/pvp_rank_api.py` · **Test:** `tests/test_pvp_rank_api.py` (35 test).

---

## 0. TL;DR

| Câu hỏi | Trả lời đo được | Bằng chứng |
|---|---|---|
| Điểm PvP lưu thế nào? | **một `int`** = `rank·1.000.000 + level·100.000 + star·10.000 + clamp(point,0,100)` | `ToPoints` RVA 19903696, 56 B — chạy 360 ca |
| Tách ra sao? | `pvpRank @0x10`, `pvpLevel @0x14`, `pvpPoints @0x18`, `totalPoints @0x1C`, `pvpStars @0x20` | `DataFromPoints` RVA 19871992, 252 B — chạy 12 ca |
| Đóng gói có tràn không? | **không** với `level ≤ 9`, `star ≤ 9`, `point ≤ 100` (90.100 < 100.000 < 1.000.000) | §2.3 |
| Điểm khôi phục được nguyên vẹn? | **108/108** ca round-trip; **trừ** `point = 100` đọc lại thành `0` | §5 |
| Ai đọc `MaxRankStars`? | **`GetRankNumber`** (RVA 19884996) — `MaxRankStars[rank].Length − level` | §4 — **đính chính 135** |
| `GetRankNumber` trả gì? | **`string`** (`Int32.ToString` ở đuôi `b` → RVA 21103836), không phải số | §4.2 |
| `IsOpen` chỉ ghi trong `..cctor`? | **Không** — `LoadRemoteConfigs` cũng ghi `false` ⇒ **fail-closed** | §6.2 — **đính chính 134** |
| Tên rank ("Bạc", "Vàng"…) | **chưa** — chuỗi tiền tố nằm ở static slot chưa resolve | §8 |

**Một câu:** ba thân method đã pin **được chạy** (không phải đọc bằng văn xuôi) bằng một interpreter AArch64 tối giản, nên công thức codec và công thức `GetRankNumber` ở đây là kết quả thi hành, và cả hai **đính chính** kết luận trước: 135 nói không method nào đọc `MaxRankStars` (sai — `GetRankNumber` đọc), 134 nói `IsOpen` chỉ được ghi trong `..cctor` (thiếu — `LoadRemoteConfigs` ghi lại `false` mỗi lần load).

---

## 1. Method đã pin

| Method | RVA (decimal) | Size | sha256 (12 ký tự đầu) |
|---|---:|---:|---|
| `ToPoints(int rank, int level, int star, int point)` | 19903696 | 56 B | `b10e8c9a2f02` |
| `DataFromPoints(int points)` | 19871992 | 252 B | `81e8a89b4b9f` |
| `GetRankNumber(int rank, int level)` | 19884996 | 160 B | `8e004bd7eeae` |
| `LoadRemoteConfigs(Action<bool>)` | 19916080 | 544 B | `9295adb973ba` |
| `..cctor()` | 19916640 | 19.944 B | `74a43a93a142` |

Nguồn byte: `reverse-engineering/raw/meta-rewards-535b0541/native.json.gz`
(sha256 `e91a8c7664666f349042d78994b7ecd53ae8e67e243c4bf3326f8cab232d4937`).
Layout field: `datas/l2_535b0541_pvp_manager_rules.json.gz` (134).

---

## 2. `ToPoints` — 4 số vào 1 `int`

### 2.1 Toàn bộ thân (16 lệnh, RVA 19903696..19903748)

```asm
19903696  mov   w9,  #0x4240        ; 0xF4240 = 1.000.000
19903700  movk  w9,  #0xf, lsl #16
19903704  mov   w10, #0x86a0        ; 0x186A0 = 100.000
19903708  cmp   w3,  #0x64          ; point ? 100
19903712  mov   w8,  #0x64          ; 100
19903716  mul   w9,  w0, w9         ; rank  × 1.000.000
19903720  movk  w10, #1, lsl #16
19903724  csel  w8,  w3, w8, lt      ; point < 100 ? point : 100
19903728  madd  w9,  w1, w10, w9    ; + level × 100.000
19903732  mov   w10, #0x2710        ; 10.000
19903736  bic   w8,  w8, w8, asr #31 ; max(point, 0)  ← clamp dưới
19903740  madd  w9,  w2, w10, w9    ; + star × 10.000
19903744  add   w0,  w9, w8
19903748  ret
```

### 2.2 Công thức

```
points = rank·1_000_000 + level·100_000 + star·10_000 + clamp(point, 0, 100)
```

* `csel ... lt` + `bic ... asr #31` = clamp **hai đầu** (`[0,100]`); verifier chạy cả `point = -5` và `point = 150`.
* Hằng số lấy từ chính lệnh (`mov`/`movk`), không chép từ báo cáo cũ: `w9 = 1.000.000`, `w10 = 100.000`, `10.000`, `100`.

### 2.3 Vì sao không tràn chữ số

| Trường | Scale | Max theo §4 (`MaxRankStars`) | Max theo `ToPoints` | Tràn? |
|---|---:|---:|---:|---|
| `point` | 1 | 100 | 100 | 100 < 100.000 ✔ |
| `star` | 10.000 | 4 (5 ô) | 9 → 90.000 | 90.000 + 100 = 90.100 < 100.000 ✔ |
| `level` | 100.000 | 4 | 9 → 900.000 | 900.000 + 99.999 < 1.000.000 ✔ |
| `rank` | 1.000.000 | 9 | unbounded | `int` chỉ chặn ở 2.147 ✔ |

Tức bố cục 4 tầng là **carry-free** trong miền dữ liệu game thật; `ToPoints` không kiểm tra `level/star` nên đầu vào ngoài miền vẫn gói được nhưng sẽ tràn khi tách.

### 2.4 360 ca đã chạy

`rank ∈ {0,1,5,9,12}`, `level ∈ {0,1,4,9}`, `star ∈ {0,3,9}`, `point ∈ {-5,0,1,99,100,150}` → **360/360** khớp công thức (không phải suy ra từ công thức: interpreter chạy từng lệnh rồi so với công thức viết độc lập).

---

## 3. `DataFromPoints` — tách ra `UserPointDataLeagues`

### 3.1 Bản đồ field

| Offset | Field (dump.cs) | Nguồn trong thân (RVA 19871992) | Công thức |
|---:|---|---|---|
| `0x10` | `pvpRank` | `stp w10, w9, [x20,#0x10]` @19872216 | `points / 1.000.000` |
| `0x14` | `pvpLevel` | ↑ | `(points % 1.000.000) / 100.000` |
| `0x18` | `pvpPoints` | `str w8, [x20,#0x18]` @19872220 | `points % 100` |
| `0x1C` | `totalPoints` | `stp w19, w11, [x20,#0x1C]` @19872212 | `points` (nguyên) |
| `0x20` | `pvpStars` | ↑ | `(points % 100.000) / 10.000` |

### 3.2 Bốn hằng số "chia bằng nhân"

| Magic (hex) | Dùng cho | Dịch | Lệnh |
|---|---|---|---|
| `0x51EB851F` | `/100` | `asr #5` sau `lsr #32` | 19872068, 19872112 |
| `0x14F8B589` | `/100.000` | `asr #13` | 19872076, 19872124 |
| `0x431BDE83` | `/1.000.000` | `asr #18` | 19872084, 19872136 |
| `0x68DB8BAD` | `/10.000` | `asr #12` | 19872160, 19872196 |

Phần dư luôn lấy bằng `msub` (`w − q·m`), nên không "đoán" bằng modulо ở phía đọc.

### 3.3 12 ca đã chạy

`points ∈ {0, 1, 99, 100, 10.000, 100.000, 999.999, 1.000.000, 1.000.001, 1.234.567, 99.999.999, 100.000.000}` — **12/12** khớp bảng §3.1.
Ví dụ `points = 1.234.567` → `pvpRank 1`, `pvpLevel 2`, `pvpStars 3`, `pvpPoints 67`, `totalPoints 1.234.567`.

### 3.4 Không kiểm tra miền

`DataFromPoints` **không** clamp và **không** so `max`: mọi `int` đều được nhận (`99.999.999` → `pvpRank 99`, `pvpLevel 9`). Chặn duy nhất nằm ở phía `ToPoints`.

---

## 4. `GetRankNumber` — người đọc `MaxRankStars` (đính chính 135)

### 4.1 Thân (sau prologue khởi tạo class, RVA 19885088..19885152)

```asm
19885088  ldr  x8, [x0, #0xb8]     ; PVP_Manager::static_fields
19885092  ldr  x0, [x8, #0x18]     ; MaxRankStars            ← 135 nói không tồn tại
19885096  cbz  x0, throw
19885108  mov  w1, w20             ; rank
19885116  bl   0x1BD7B94           ; List<int[]>.get_Item(rank)
19885124  ldr  w8, [x0, #0x18]     ; int[] .Length
19885136  sub  w0, w8, w19         ; cells − level
19885148  b    0x14204DC           ; Int32.ToString(string)  ← tail call
```

Nên **`GetRankNumber(rank, level) = số ô của rank − level`**, và trả về **chuỗi** (tên method gây hiểu nhầm: nó là helper hiển thị, không phải bộ đếm).

### 4.2 44 ca đã chạy (đúng bằng tổng số ô của 10 rank)

| rank | số ô | `GetRankNumber(rank, level)` cho `level = 0..` |
|---:|---:|---|
| 0 | 3 | `3, 2, 1` |
| 1 | 3 | `3, 2, 1` |
| 2 | 4 | `4, 3, 2, 1` |
| 3 | 4 | `4, 3, 2, 1` |
| 4..9 | 5 | `5, 4, 3, 2, 1` |

Số ô khớp **chính xác** `rank_table` của 135 (`3,3,4,4,5,5,5,5,5,5`) — đây là phép kiểm chéo hai artifact độc lập: 135 đo *độ dài mảng khai báo*, 136 *chạy code* trên bảng đó và ra cùng con số. Interpreter chỉ "giả" hai chỗ: `List.get_Item` (trả độ dài mảng của rank) và `Int32.ToString` (ghi lại đối số). Không có phần nào của phép tính `cells − level` được giả.

### 4.3 Vì sao 135 bỏ sót

135 quét mẫu cố định `ldr x8, [x8, #0xb8]`. Trong `GetRankNumber`, statics base vào **`x0`** (`ldr x0,[x8,#0x18]`), nên mẫu đó không khớp. 136 thay quét-mẫu bằng **theo dõi thanh ghi** qua 4 bước: `adrp+ldr` → slot → `[slot]` = klass → `[klass,#0xb8]` = statics → truy cập field (xem §6).

---

## 5. Round-trip và chỗ **không** khôi phục được

108 ca (`rank ∈ {0,1,9,12}` × `level ∈ {0,4,9}` × `star ∈ {0,5,9}` × `point ∈ {0,42,99}`):
`DataFromPoints(ToPoints(r,l,s,p))` trả lại đúng `(r,l,s,p)` — **108/108**.

**Ngoại lệ đo được:** `point = 100` (đúng biên clamp trên) được gói thành `...0100`, nhưng `pvpPoints = points % 100 = 0`. Nghĩa là **biên trên của clamp không biểu diễn được**: giá trị 100 và 0 chia cùng một ô. Game đọc lại sẽ thấy `0`. Đây là khác biệt *cấu trúc*, không phải lỗi làm tròn — nên ghi thành `saturation` trong artifact chứ không "sửa" công thức.

---

## 6. Bản đồ truy cập statics (thay cho quét mẫu)

### 6.1 Slot klass của `PVP_Manager`

Mọi method đều lấy statics qua một **metadata slot** giữ con trỏ klass:

```text
adrp xP, #page            ; page
ldr  xR, [xP, #off]       ; R = giá trị slot (page + off)
ldr  xK, [xR]             ; K = klass
ldr  xS, [xK, #0xb8]      ; S = klass->static_fields
ldr/str … , [xS, #field]  ; truy cập static field
```

Slot **`0x2ADFE40` = 44957248** được chứng minh là `PVP_Manager`: `GetRankNumber` đi qua nó để đọc `+0x18`, và khi chạy thân đó trên bảng của 135 thì ra đúng `cells − level` (§4.2). Đây là **suy ra từ thi hành**, không phải từ tên symbol.

### 6.2 Kết quả (4 method, 14 truy cập)

| Method | RVA | Truy cập | Offset |
|---|---:|---|---:|
| `..cctor` | 19916640 | 11 × **write** | `0, 8, 16, 24, 32, 40, 48, 56, 64, 72, 76` |
| `GetSeasonRewards` | 19915396 | 1 × read | `0` (`AllSeasonRewards`) |
| `GetRankNumber` | 19884996 | 1 × read @19885092 | `24` (`MaxRankStars`) |
| `LoadRemoteConfigs` | 19916080 | 1 × **write** @19916560 | `76` (`IsOpen`) |

**Hai lần đọc bị loại** (`rejected_reads`): RVA 19916324 và 19916376 trong `LoadRemoteConfigs` đi qua slot `0x2ADB958` (44939608) — **không phải** `PVP_Manager`, dù cũng đọc `+0xb8` rồi field `+0`. Nếu không tách theo slot, hai dòng này sẽ bị gán sai thành "đọc `AllSeasonRewards`", tức artifact sẽ **bịa** thêm 2 truy cập.

### 6.3 Hệ quả của `IsOpen` (đính chính 134)

`LoadRemoteConfigs` ghi `strb wzr, [statics,#0x4C]` **sau khi** gọi remote xong → mỗi lần load cấu hình, bảng PvP bị đặt `false`. Nghĩa là trạng thái mở bảng **fail-closed**: phải có phản hồi remote thành công mới mở, mất mạng thì đóng. 134 chỉ thấy phép ghi trong `..cctor` nên mô tả `IsOpen = false` như *giá trị khởi tạo*, thiếu ý "bị đặt lại sau mỗi lần load".

---

## 7. Đối chiếu 127 / 128

| Nguồn | Nói gì | 136 |
|---|---|---|
| 127 §6.5 | công thức `ToPoints`/`DataFromPoints` (level D) | **xác nhận** cả hai công thức, kèm hằng số lấy từ lệnh |
| 128 §3.4 | giá trị `MaxRankStars` | khớp (đã xác nhận ở 135) |
| 134 | `IsOpen` chỉ ghi trong `..cctor` | **đính chính**: `LoadRemoteConfigs` cũng ghi |
| 135 | "15 method không method nào chạm statics `+0x18`" | **đính chính**: `GetRankNumber` chạm, qua `x0` không qua `x8` |

---

## 8. `not_decoded` (3 mục, giữ nguyên trung thực)

| Mục | Bước chặn |
|---|---|
| Tên rank hiển thị | `GetRankName` (RVA 19881572) ghép chuỗi tiền tố ở static slot `0x2ADCAE0` / `0x2ADB0B38` với `rank.ToString()` + `GetRankNumber()`; slot chuỗi không có trong raw đã pin nên **không trích dẫn được** tên |
| Cấu hình rank do server trả | `LoadRemoteConfigs` gọi remote rồi mới đổ vào `pvpDatas`; APK không chứa payload server → **`MODEL_NOT_MEASURED runtime`** |
| Level 0 của rank 0 | `GetRankNumber` chứng minh rank 0 có **3 ô** (level 0..2) trong khi `AllRewards` chỉ có dòng thưởng cho level 1..2 — không có code đã pin giải thích ô level 0 |

---

## 9. Tái lập

```bash
python3 tools/verify/pvp_rank_api.py            # in bytes/sha256 + số ca
python3 -m unittest tests.test_pvp_rank_api      # 35 test
python3 tools/verify-claims.py --require AB,AO,AP
```

`evidence: STATIC_ONLY_ORIGINAL_APK` · nguồn: `meta-rewards-535b0541/native.json.gz`,
`datas/l2_535b0541_max_rank_stars.json.gz`, `datas/l2_535b0541_pvp_manager_rules.json.gz`,
`reverse-engineering/il2cpp/dump.cs.gz` (4 nguồn, sha256 từng file ghi trong artifact).

---

`provenance:` APK gốc `535b0541` (xapk sha256 trong artifact) → `libil2cpp.so` → raw `meta-rewards-535b0541` → verifier → artifact 3172 B `7663d2fd…` → 35 test. Không dùng emulator/probe/device.
